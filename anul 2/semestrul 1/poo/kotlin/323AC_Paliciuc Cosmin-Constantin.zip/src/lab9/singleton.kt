package lab9

class Singleton